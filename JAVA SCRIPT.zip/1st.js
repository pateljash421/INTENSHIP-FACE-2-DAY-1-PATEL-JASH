alert("hello world");
alert("external");